module.exports = {
    APIServer:'http://142.93.107.114:4000/api/v1', 
    WebSocketServer: 'ws://142.93.107.114:4000/api/v1'
};
