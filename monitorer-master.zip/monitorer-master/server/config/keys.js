module.exports = {
    database:'mongodb://TEST:test1234@ds237588.mlab.com:37588/monitorer'
};
